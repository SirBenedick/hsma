package uebung04;
import static pr.MakeItSimple.*;

public class TreeNode {
	private TreeNode father = null;
	private Comparable[] elements;
	private TreeNode[] children;
	private int order;

	public TreeNode(int order) {
		this.order = order;
		elements = new Comparable[order * 2 + 1];
		children = new TreeNode[order * 2 + 2];
	}

	//"BIG" - methods
	public void insert(Comparable o) {
		println("insert " + o.toString());
		//find correct position in elements array
		int pos = -1;
		do{
			pos++;
			if( pos >= elements.length)
				break;
		}while((elements[pos] != null && elements[pos].compareTo(o) < 0));

		//add new value in order into elements
		Comparable[] tempElements = new Comparable[elements.length];
		tempElements[pos] = o;
		int t = 0;
		for (int i = 0; i < tempElements.length; i++) {
			if(tempElements[i] == null){
				tempElements[i] = elements[t];
				t++;
			}
		}
		elements = tempElements;
		
		//handle burst
		if(valuesInNode(elements) == elements.length){
			split();
		}
	}

	private void split(){
		println("split");
		int mid = (elements.length) /2;
		
		TreeNode rightNode = new TreeNode(order);
		
		//insert elements and children right from mid
		for (int i = mid + 1; i < elements.length; i++) {
			rightNode.insert(elements[i]);
			elements[i] = null;
		}
		for (int i = children.length/2 -1 ; i < children.length; i++) {
			if(children[i] != null){
				rightNode.setChild(children[i]);
				children[i] = null;
			}
		}
		Comparable tempMid = elements[mid];
		elements[mid] = null;
		
		//checking/setting father and adding new children 
		if(father == null){
			father = new TreeNode(order);
			rightNode.father = this.father;
			
			father.insert(tempMid);
			father.setChild(this);
			father.setChild(rightNode);
		}
		else{
			rightNode.father = this.father;
			
			father.insert(tempMid);
			father.setChild(rightNode);
		}		
	}
	
	private void setChild(TreeNode child) {
		println("setChild");
		//find position of child in current children array
		Comparable min = child.getMin();
		int pos = getPosition(min) + 1; //if child is empty getPosition returns -1 -> is shifted compared to elements, therfore +1
		if(pos == 0)
			children[0] = child;
		else{
			TreeNode[] tempChildren = new TreeNode[children.length];
			tempChildren[pos] = child; 
			int x = 0;
			for (int i = 0; i < tempChildren.length; i++) {
				if(tempChildren[i] == null){
					tempChildren[i] = children[x];
					x++;
				}
			}
			children = tempChildren;	
		}
	}
	
	public TreeNode findNode(Comparable o) { //returns node containing element
		println("findeNode:  " + o.toString());
		TreeNode node;
		if( contains(o) )
			return this;
		
		node = inRange(o);
		if(node == null)
			return null;
		
		return node.findNode(o);
	}
	
	public TreeNode findNodeInsert(Comparable o) { //return node where element needs to be inserted
		println("findeNodeInsert " + o.toString());
		TreeNode node;
		if( contains(o) )
			return null;
		
		node = inRange(o);
		if(node == null)
			return this;
		//tree grows to root
		if(node.isEmpty())
			return this;
		
		return node.findNodeInsert(o);
	}
	
	public TreeNode inRange(Comparable o) {
		println("inRange: " + o.toString());
		if(elements[0] == null)
			return this;
		//value smaller than smallest element
		if(elements[0].compareTo(o) > 0){
			return children[0];
		}
		//value bigger than biggest element
		if(children[children.length-2] != null && elements[elements.length-2] != null){
			if(elements[elements.length-2].compareTo(o) > 0){
				return children[children.length-2];
			}
		}
		//finding child between elements
		for (int i = 0; i < elements.length - 1; i++) {
			if( elements[i] != null && elements[i+1] != null && elements[i].compareTo(o) < 0 && elements[i+1].compareTo(o) > 0){
				return children[i+1];
			}
		}
		
		return null;
	}
	
	
	
	//"small" - methods
	public Comparable[] getElements(){
		return elements;
	}
	
	public TreeNode[] getChildren(){
		return children;
	}
	
	private int getPosition(Comparable o){
		println("getPosition: " + o.toString());
		int pos = -1;
		for (int i = 0; i < elements.length; i++) {
			if( elements[i] != null && elements[i].compareTo(o) < 0 ){
				pos++;
			}
		}
		return pos;
	}

	private Comparable getMin() {
		return elements[0];	
	}

	@Override
	public String toString(){
		String values = "";
		for (int i = 0; i < elements.length; i++) {
			if(elements[i] != null)
				values += elements[i].toString() + " ";
		}
		return values;		
	}
	
	private boolean isEmpty() {
		for (int i = 0; i < elements.length; i++) {
			if(elements[i] != null)
				return false;
		}
		return true;
	}
	
	public TreeNode checkRoot() { //returns the root of the tree
		
		if(father == null)
			return this;
		return father.checkRoot();
	}
	
	public boolean contains(Comparable o){
		println("contains: " + o.toString());
		int pos = getPosition(o);
		
		if(pos == -1)
			return false;
		else
			return true;
	}
	
	private int valuesInNode( Comparable[] elements ){ //returns number of elements
		println("valuesInNode");
		int values = 0;
		for (int i = 0; i < elements.length; i++) {
			if( elements[i] != null)
				values++;
		}
		return values;
	}
	
}
