package uebung04;

import static pr.MakeItSimple.*;

import java.util.LinkedList;

public class MyBTree implements BTree {

	int order;
	TreeNode root = null;

	public MyBTree(int order) {
		this.order = order;
	}

	@Override
	public boolean insert(Comparable o) {
		if (root == null) {
			TreeNode node = new TreeNode(order);
			node.insert(o);
			root = node;
			return true;
		}
		
		root = root.checkRoot();
		TreeNode node = root.findNodeInsert(o);
		node.insert(o);

		root = node.checkRoot();
		return false;
	}

	private TreeNode findNode(Comparable o) {
		return root.findNode(o);
	}
	
	@Override
	public boolean insert(String filename) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override 
	public boolean contains(Comparable o) { //noch nicht getestet
		if(root.findNodeInsert(o) == null)
			return false;
		return true;
	}

	@Override
	public void delete(Comparable obj) {
		// TODO Auto-generated method stub

	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int height() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Comparable getMax() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Comparable getMin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public MyBTree addAll(MyBTree otherTree) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void printInorder() {
		printInorderRecursively(root);
	}

	private void printInorderRecursively(TreeNode node) { //Funktioniert nicht 
		if (node != null) {
			TreeNode[] children = node.getChildren();
			for (int i = 0; i < children.length; i++) {
				if (children[i] != null) {
					printInorderRecursively(children[i]);
					Comparable[] elements = node.getElements();
					if(elements[i] != null)
					print(elements[i].toString());
				}
			}
		}
	}

	@Override
	public void printPostorder() {
		// TODO Auto-generated method stub

	}

	@Override
	public void printPreorder() {
		// TODO Auto-generated method stub

	}

	@Override
	public void printLevelorder() { //levelangabe funktioniert noch nicht
		int level = 1;
		if (root != null) {
			TreeNode node = root;
			LinkedList<TreeNode> queue = new LinkedList<TreeNode>();
			queue.addLast(node);
			TreeNode[] children = node.getChildren();
			while (!queue.isEmpty()) {
				for (int i = 0; i < children.length; i++) {
					if (children[i] != null)
						queue.addLast(children[i]);
				}
				println("Level: " + level);
				println(queue.poll().toString()); 
													
				if (!queue.isEmpty()){
					node = queue.getFirst();
					level++;	
				}
				children = node.getChildren();
				
			}
		}
	}

	public static void main(String[] args) {
		MyBTree tree = new MyBTree(2);
		 int x = 100;
		 for (int i = 0; i < 97; i++) {
		 tree.insert(x--);
		 println("x: " + x);
		 }
		 tree.printLevelorder();
	}
}
